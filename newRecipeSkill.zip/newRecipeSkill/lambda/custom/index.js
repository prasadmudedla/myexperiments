// Lambda Function code for Alexa.
// Paste this into your index.js file.


const https = require("https");
const Alexa = require('ask-sdk-core');
const i18n = require('i18next');
const sprintf = require('i18next-sprintf-postprocessor');

const invocationName = "breakfast recipe";

// 1. Intent Handlers =============================================

const AMAZON_CancelIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.CancelIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;


    let say = 'Okay, talk to you later! ';

    return responseBuilder
      .speak(say)
      .getResponse();
  },
};

const AMAZON_HelpIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;


    let say = 'you asked for help.';

    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const AMAZON_NextIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.NextIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from AMAZON.NextIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const AMAZON_PreviousIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.PreviousIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from AMAZON.PreviousIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const AMAZON_NoIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.NoIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from AMAZON.NoIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const AMAZON_PauseIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.PauseIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from AMAZON.PauseIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const AMAZON_RepeatIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.RepeatIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from AMAZON.RepeatIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const AMAZON_StartOverIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.StartOverIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from AMAZON.StartOverIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const AMAZON_StopIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.StopIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;


    let say = 'Okay, talk to you later! ';

    return responseBuilder
      .speak(say)
      .getResponse();
  },
};

const AMAZON_YesIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.YesIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from AMAZON.YesIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const CookIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'CookIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from CookIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const IngredientsIntent_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' && request.intent.name === 'IngredientsIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;

    const responseBuilder = handlerInput.responseBuilder;

    let say = 'Hello from IngredientsIntent. ';


    return responseBuilder
      .speak(say)
      .reprompt('try again, ' + say)
      .getResponse();
  },
};

const LaunchRequest_Handler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'LaunchRequest';
  },
  handle(handlerInput) {
    const attributesManager = handlerInput.attributesManager;
    const responseBuilder = handlerInput.responseBuilder;
    const requestAttributes = attributesManager.getRequestAttributes();
    const speechOutput = `${requestAttributes.t('WELCOME')} ${requestAttributes.t('HELP')}`;

    // let say = 'welcome' + ' to ' + invocationName + ' ! Say help to hear some options.';

    let skillTitle = capitalize(invocationName);

    if (supportsDisplay(handlerInput)) {
      const myImage1 = new Alexa.ImageHelper()
        .addImageInstance(DisplayImg1.url)
        .getImage();

      const myImage2 = new Alexa.ImageHelper()
        // .addImageInstance(DisplayImg2.url)
        .addImageInstance(welcomeCardImg.largeImageUrl)
        .getImage();

      const primaryText = new Alexa.RichTextContentHelper()
        .withPrimaryText('Welcome to the skill!')
        .getTextContent();

      responseBuilder.addRenderTemplateDirective({
        type: 'BodyTemplate2',
        token: 'string',
        backButton: 'HIDDEN',
        backgroundImage: myImage2,
        image: myImage1,
        title: skillTitle,
        textContent: primaryText,
      });
    }

    return responseBuilder
      .speak(speechOutput)
      .reprompt('try again, ' + speechOutput)
      .withStandardCard('Welcome!',
        'Hello!\nThis is a card for your skill, ' + skillTitle,
        welcomeCardImg.smallImageUrl, welcomeCardImg.largeImageUrl)
      .getResponse();
  },
};

const SessionEndedHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);
    return handlerInput.responseBuilder.getResponse();
  }
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    const request = handlerInput.requestEnvelope.request;

    console.log(`Error handled: ${error.message}`);
    console.log(`Original Request was: ${JSON.stringify(request, null, 2)}`);

    return handlerInput.responseBuilder
      .speak('Sorry, I can not understand the command.  Please say again.')
      .reprompt('Sorry, I can not understand the command.  Please say again.')
      .getResponse();
  }
};


// 2. Constants ===========================================================================

// Here you can define static data, to be used elsewhere in your code.  For example:
//    const myString = "Hello World";
//    const myArray  = [ "orange", "grape", "strawberry" ];
//    const myObject = { "city": "Boston",  "state":"Massachusetts" };

const APP_ID = undefined; // TODO replace with your Skill ID (OPTIONAL).

// 3.  Helper Functions ===================================================================

function capitalize(myString) {

  return myString.replace(/(?:^|\s)\S/g, function(a) {
    return a.toUpperCase();
  });
}


function randomPhrase(myArray) {
  return (myArray[Math.floor(Math.random() * myArray.length)]);
}


function resolveCanonical(slot) {
  let canonical = '';
  if (slot.hasOwnProperty('resolutions')) {
    canonical = slot.resolutions.resolutionsPerAuthority[0].values[0].value.name;
  } else {
    canonical = slot.value;
  }

  return canonical;
}


function getSlotValues(filledSlots) {
  const slotValues = {};

  console.log(`The filled slots: ${JSON.stringify(filledSlots)}`);
  Object.keys(filledSlots).forEach((item) => {
    const name = filledSlots[item].name;

    if (filledSlots[item] &&
      filledSlots[item].resolutions &&
      filledSlots[item].resolutions.resolutionsPerAuthority[0] &&
      filledSlots[item].resolutions.resolutionsPerAuthority[0].status &&
      filledSlots[item].resolutions.resolutionsPerAuthority[0].status.code) {
      switch (filledSlots[item].resolutions.resolutionsPerAuthority[0].status.code) {
        case 'ER_SUCCESS_MATCH':
          slotValues[name] = {
            synonym: filledSlots[item].value,
            resolved: filledSlots[item].resolutions.resolutionsPerAuthority[0].values[0].value.name,
            isValidated: true
          };
          break;
        case 'ER_SUCCESS_NO_MATCH':
          slotValues[name] = {
            synonym: filledSlots[item].value,
            resolved: filledSlots[item].value,
            isValidated: false
          };
          break;
        default:
          break;
      }
    } else {
      slotValues[name] = {
        synonym: filledSlots[item].value,
        resolved: filledSlots[item].value,
        isValidated: false
      };
    }
  }, this);

  return slotValues;
}

function supportsDisplay(handlerInput) // returns true if the skill is running on a device with a display (Echo Show, Echo Spot, etc.)
{ //  Enable your skill for display as shown here: https://alexa.design/enabledisplay
  const hasDisplay =
    handlerInput.requestEnvelope.context &&
    handlerInput.requestEnvelope.context.System &&
    handlerInput.requestEnvelope.context.System.device &&
    handlerInput.requestEnvelope.context.System.device.supportedInterfaces &&
    handlerInput.requestEnvelope.context.System.device.supportedInterfaces.Display;

  return hasDisplay;
}


// 1. Text strings =====================================================================================================
//    Modify these strings and messages to change the behavior of your Lambda function

const languageStrings = {
  'en': {
    'translation': {
      'WELCOME': "Welcome to the Breakfast Sandwich Recipe skill. ",
      'TITLE': "Breakfast Sandwich",
      'HELP': "This skill will show you how to make a breakfast sandwich.  You can ask for the list of ingredients, or just say begin cooking if you are ready. Once you are cooking, just say Next to advance to the next step in the recipe. You can also pause the recipe at any time by saying Pause.",
      'STOP': "Okay, see you next time! "
    }
  }
  ,
  en-IN: {
    translation: {
      WELCOME: 'Welcome to Gloucester Guide!',
      HELP: 'Say about, to hear more about the city, or say coffee, breakfast, lunch, or dinner, to hear local restaurant suggestions, or say recommend an attraction, or say, go outside. ',
      ABOUT: 'Gloucester Massachusetts is a city on the Atlantic Ocean.  A popular summer beach destination, Gloucester has a rich history of fishing and ship building.',
      STOP: 'Okay, see you next time!',
    }
  }
  // , 'de-DE': { 'translation' : { 'WELCOME'   : "Guten Tag etc." } }
};
const data = {
  // TODO: Replace this data with your own.
  "ingredients": [{
      "name": "bread",
      "qty": 2,
      "units": "pieces of"
    },
    {
      "name": "egg",
      "qty": 1,
      "units": ""
    },
    {
      "name": "cheese",
      "qty": 1,
      "units": "slice of"
    }
  ],
  "steps": [
    "Heat a frying pan on your stove over medium heat.",
    "Crack an egg in the skillet and heat until the egg becomes firm.",
    "Flip the egg with a spatula.",
    "Lay the cheese on top of the egg.",
    "Using a spatula, remove egg and cheese and place on one piece of bread.",
    "Place second piece of bread over the egg and cheese.",
    "Serve."
  ]
};

const welcomeCardImg = {
  smallImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_small.png',
  largeImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_large.png'
};

const DisplayImg1 = {
  title: 'Jet Plane',
  url: 'https://s3.amazonaws.com/skill-images-789/display/plane340_340.png'
};
const DisplayImg2 = {
  title: 'Starry Sky',
  url: 'https://s3.amazonaws.com/skill-images-789/display/background1024_600.png'

};

const LocalizationInterceptor = {
  process(handlerInput) {
    const localizationClient = i18n.use(sprintf).init({
      lng: handlerInput.requestEnvelope.request.locale,
      overloadTranslationOptionHandler: sprintf.overloadTranslationOptionHandler,
      resources: languageString,
      returnObjects: true
    });

    const attributes = handlerInput.attributesManager.getRequestAttributes();
    attributes.t = function(...args) {
      return localizationClient.t(...args);
    };
  },
};


// 4. Exports handler function and setup ===================================================
const skillBuilder = Alexa.SkillBuilders.custom();
exports.handler = skillBuilder
  .addRequestHandlers(
    LaunchRequest_Handler,
    AMAZON_CancelIntent_Handler,
    AMAZON_HelpIntent_Handler,
    AMAZON_NextIntent_Handler,
    AMAZON_PreviousIntent_Handler,
    AMAZON_NoIntent_Handler,
    AMAZON_PauseIntent_Handler,
    AMAZON_RepeatIntent_Handler,
    AMAZON_StartOverIntent_Handler,
    AMAZON_StopIntent_Handler,
    AMAZON_YesIntent_Handler,
    CookIntent_Handler,
    IngredientsIntent_Handler,
    SessionEndedHandler
  )
  .addRequestInterceptors(LocalizationInterceptor)
  .addErrorHandlers(ErrorHandler)
  // .addResponseInterceptors(MyResponseInterceptor)
  .lambda();
// End Skill Code
